dsClient
=======

[![Build Status](https://travis-ci.org/datashield/dsClient.svg?branch=repo-merge.base.release)](https://travis-ci.org/datashield/dsClient)
[![codecov.io](https://codecov.io/github/datashield/dsClient/coverage.svg?branch=repo-merge.base.release)](https://codecov.io/github/datashield/dsClient?branch=repo-merge.base.release)
[![License](https://img.shields.io/badge/license-GPLv3-blue.svg)](https://www.gnu.org/licenses/gpl-3.0.html)

Client-side DataSHIELD functions
